exports.id = 480;
exports.ids = [480];
exports.modules = {

/***/ 2480:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Common_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7730);
/* harmony import */ var _styles_Common_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Common_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services_question__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6240);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_question__WEBPACK_IMPORTED_MODULE_2__]);
_services_question__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

 // 需要引入Script
// import Script from "next/script";


 // import { useParams } from "next/navigation";





const PageWrapper = props => {
  const {
    title,
    id = "",
    desc,
    css,
    js = "",
    lines = [],
    children
  } = props; // console.log("@", js);
  // const { id = "" } = useParams();
  // 更新页面展示次数

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const update = async () => {
      await (0,_services_question__WEBPACK_IMPORTED_MODULE_2__/* .updateShowDocNum */ .UW)(id, lines[0].link);
    };

    update();
  }, [id, lines]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // 动态创建 <script> 标签
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.async = true;
    script.innerHTML = `
    !(function (w, d, t) {
      w.TiktokAnalyticsObject = t;
      var ttq = (w[t] = w[t] || []);
      (ttq.methods = [
        "page",
        "track",
        "identify",
        "instances",
        "debug",
        "on",
        "off",
        "once",
        "ready",
        "alias",
        "group",
        "enableCookie",
        "disableCookie",
        "holdConsent",
        "revokeConsent",
        "grantConsent",
      ]),
        (ttq.setAndDefer = function (t, e) {
          t[e] = function () {
            t.push([e].concat(Array.prototype.slice.call(arguments, 0)));
          };
        });
      for (var i = 0; i < ttq.methods.length; i++)
        ttq.setAndDefer(ttq, ttq.methods[i]);
      (ttq.instance = function (t) {
        for (var e = ttq._i[t] || [], n = 0; n < ttq.methods.length; n++)
          ttq.setAndDefer(e, ttq.methods[n]);
        return e;
      }),
        (ttq.load = function (e, n) {
          var r = "https://analytics.tiktok.com/i18n/pixel/events.js",
            o = n && n.partner;
          (ttq._i = ttq._i || {}),
            (ttq._i[e] = []),
            (ttq._i[e]._u = r),
            (ttq._t = ttq._t || {}),
            (ttq._t[e] = +new Date()),
            (ttq._o = ttq._o || {}),
            (ttq._o[e] = n || {});
          n = document.createElement("script");
          (n.type = "text/javascript"),
            (n.async = !0),
            (n.src = r + "?sdkid=" + e + "&lib=" + t);
          e = document.getElementsByTagName("script")[0];
          e.parentNode.insertBefore(n, e);
        });
      ttq.load(${lines.length > 0 ? JSON.stringify(lines && lines[0].pixels) : JSON.stringify("123456789")} );
      ttq.page();
    })(window, document, "ttq");
    `; // 将脚本插入到 <head>

    document.head.appendChild(script);
    return () => {
      // 在组件卸载时移除脚本
      document.head.removeChild(script);
    };
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("title", {
        children: title
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("meta", {
        name: "description",
        content: desc
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("link", {
        rel: "icon",
        href: "/favicon.ico"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("style", {
        children: css
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("script", {
        id: "Pixel",
        dangerouslySetInnerHTML: {
          __html: js
        }
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("main", {
      className: (_styles_Common_module_scss__WEBPACK_IMPORTED_MODULE_4___default().container),
      children: children
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageWrapper);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6240:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UW": () => (/* binding */ updateShowDocNum),
/* harmony export */   "kt": () => (/* binding */ getLineByDomainName),
/* harmony export */   "qi": () => (/* binding */ updateClickNum),
/* harmony export */   "xL": () => (/* binding */ getQuestionById)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4992);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_request__WEBPACK_IMPORTED_MODULE_0__]);
_request__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // 获取问卷
// export async function getQuestionById(id: string) {
//   const url = `/api/question/${id}`;
//   const data = await get(url);
//   return data;
// }
// 获取问卷
// 获取单个问卷

async function getQuestionById(id) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/question/${id}`);
} // 获取line表
// export async function getLineByDomainName(domainName: string) {
//   const url = `/api/line?domainName=${domainName}`;
//   const data = await get(url);
//   return data;
// }

async function getLineByDomainName(domainName) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/line?domainName=${domainName}`);
} // 更新页面展示次数
// export async function updateShowDocNum(domainName: string, link: string) {
//   const url = `/api/line/showdocumentnum?domainName=${domainName}&link=${link}`;
//   const data = await get(url);
//   return data;
// }

async function updateShowDocNum(domainName, link) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/line/showdocumentnum?domainName=${domainName}&link=${link}`);
} // 更新点击次数
// export async function updateClickNum(domainName: string, link: string) {
//   const url = `/api/line/clicknum?domainName=${domainName}&link=${link}`;
//   const data = await get(url);
//   return data;
// }

async function updateClickNum(domainName, link) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/line/clicknum?domainName=${domainName}&link=${link}`);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4992:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = "https://000america.shop:3000"; // 创建 axios 实例

const request = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
  // baseURL: "http://lkkhyy_s.lkkxwj.shop:5502",
  baseURL: API_URL,
  timeout: 5000 // 请求超时时间

}); // 请求拦截器

request.interceptors.request.use(config => {
  // 在这里可以添加全局请求头或 Token
  config.headers["Content-Type"] = "application/json";
  return config;
}, error => {
  return Promise.reject(error);
}); // 响应拦截器

request.interceptors.response.use(response => {
  return response.data; // 只返回数据部分
}, error => {
  console.error("Request error:", error);
  return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (request);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7730:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Common_container__ihMgL"
};


/***/ })

};
;