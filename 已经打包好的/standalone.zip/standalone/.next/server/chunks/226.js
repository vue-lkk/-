"use strict";
exports.id = 226;
exports.ids = [226];
exports.modules = {

/***/ 226:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ar": () => (/* binding */ updatePixelsByDomainName),
/* harmony export */   "Gq": () => (/* binding */ updateBanned),
/* harmony export */   "Ir": () => (/* binding */ deleteByNation),
/* harmony export */   "Mn": () => (/* binding */ createTemplate),
/* harmony export */   "cc": () => (/* binding */ getToLines),
/* harmony export */   "hs": () => (/* binding */ updateResetClick),
/* harmony export */   "p$": () => (/* binding */ createByNation),
/* harmony export */   "qG": () => (/* binding */ toggleLink),
/* harmony export */   "rg": () => (/* binding */ addByNation),
/* harmony export */   "t$": () => (/* binding */ getQuestionByuserName),
/* harmony export */   "xq": () => (/* binding */ getQuestionByDomainName)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4992);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_request__WEBPACK_IMPORTED_MODULE_0__]);
_request__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // 根据域名获取单个后台

async function getQuestionByDomainName(domainName) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/check?domainName=${domainName}`);
} // 上线/下线

async function toggleLink(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/updateline`, data);
} // 根据域名统一修改当前域名像素

async function updatePixelsByDomainName(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/update`, data);
} // 获取模板后台

async function getQuestionByuserName(userName) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/checkbyusername?userName=${userName}`);
} // 批量添加-根据国家来批量统一添加

async function addByNation(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/add`, data);
} // 批量添加-根据国家来批量统一删除

async function deleteByNation(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/delete`, data);
} // 新建后台

async function createByNation(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/create`, data);
} // 新建后台模板

async function createTemplate(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/template`, data);
} // 封禁/解封

async function updateBanned(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/banned`, data);
} // 获取上线

async function getToLines(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/gettopline?domainName=${data}`);
} // 重置点击量

async function updateResetClick(data) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/clearclick`, data);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4992:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = "https://000america.shop:3000"; // 创建 axios 实例

const request = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
  // baseURL: "http://lkkhyy_s.lkkxwj.shop:5502",
  baseURL: API_URL,
  timeout: 5000 // 请求超时时间

}); // 请求拦截器

request.interceptors.request.use(config => {
  // 在这里可以添加全局请求头或 Token
  config.headers["Content-Type"] = "application/json";
  return config;
}, error => {
  return Promise.reject(error);
}); // 响应拦截器

request.interceptors.response.use(response => {
  return response.data; // 只返回数据部分
}, error => {
  console.error("Request error:", error);
  return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (request);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;