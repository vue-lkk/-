"use strict";
(() => {
var exports = {};
exports.id = 112;
exports.ids = [112];
exports.modules = {

/***/ 1020:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var antd_lib_drawer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8000);
/* harmony import */ var antd_lib_drawer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_drawer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4285);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_table__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6190);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_form__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_tag__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1886);
/* harmony import */ var antd_lib_tag__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tag__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7374);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_space__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2024);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_switch__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_line__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(226);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_line__WEBPACK_IMPORTED_MODULE_9__]);
_services_line__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function Home(props) {
  const {
    dataLines,
    domainName
  } = props;
  console.log(dataLines); // 号列表

  const {
    0: lists,
    1: setLists
  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(dataLines.lines || []); // 编辑项

  const {
    0: changeLine,
    1: setChangeLine
  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({}); // 切换上线/下线

  const [messageApi, contextHolder] = antd_lib_message__WEBPACK_IMPORTED_MODULE_8___default().useMessage(); // 关键！


  const targge = async (checked, event) => {
    try {
      // 前端切换 上线/下线
      setLists(lists => {
        const newLists = lists.map(item => {
          if (item.lineName === event.lineName) {
            item.status = checked ? 1 : 0;
          }

          return item;
        });
        return newLists;
      }); // 后端切换 上线/下线

      const data = {
        // _id: props.id,
        domainName,
        // 域名
        lineName: event.lineName,
        // 号
        status: checked ? 1 : 0 // 状态

      };
      const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_9__/* .toggleLink */ .qG)(data); // API调用成功后再显示消息

      messageApi.open({
        type: "success",
        content: "状态更新成功"
      });
    } catch (error) {
      messageApi.open({
        type: "error",
        content: "更新失败，请重试"
      });
    }
  }; // 修改信息


  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false); // 打开抽屉

  const showDrawer = text => {
    const {
      lineName,
      comment,
      pixels
    } = text;
    console.log(lineName, comment, pixels);
    setOpen(true);
    setChangeLine(text);
  }; // 关闭抽屉


  const onClose = () => {
    setOpen(false);
  }; // 重置点击


  const resetClick = async values => {
    console.log(domainName, values);

    try {
      // 前端修改
      setLists(lists => {
        const newLists = lists.map((item, index) => {
          // 重置指定号点击量
          if (index === values.key) {
            item.clickNum = 0;
          }

          return item;
        });
        return newLists;
      }); // 后端修改

      const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_9__/* .updateResetClick */ .hs)({
        domainName,
        lineName: values.lineName
      });
      console.log("Success:", values, res);
      messageApi.open({
        type: "success",
        content: res.message
      });
    } catch (error) {
      messageApi.open({
        type: "error",
        content: "修改失败，请重试"
      });
    }
  }; // table表单


  const columns = [{
    title: "状态",
    key: "status",
    render: text => {
      const check = text.status === 0 ? true : false;
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_space__WEBPACK_IMPORTED_MODULE_6___default()), {
        direction: "vertical",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_switch__WEBPACK_IMPORTED_MODULE_7___default()), {
          checkedChildren: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_11__.CheckOutlined, {}),
          unCheckedChildren: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_11__.CloseOutlined, {}),
          defaultChecked: text.status == "0" ? false : true,
          onClick: () => targge(check, text)
        })
      });
    }
  }, {
    title: "备注",
    dataIndex: "comment",
    key: "comment"
  }, {
    title: "号",
    dataIndex: "lineName",
    key: "lineName"
  }, {
    title: "链接",
    key: "link",
    dataIndex: "link"
  }, {
    title: "像素",
    key: "pixels",
    dataIndex: "pixels"
  }, {
    title: "点击",
    key: "clickNum",
    // dataIndex: "clickNum",
    render: (_, record) => {
      console.log("DDD", _);
      return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)((antd_lib_space__WEBPACK_IMPORTED_MODULE_6___default()), {
        size: "middle",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_tag__WEBPACK_IMPORTED_MODULE_5___default()), {
          color: "success",
          children: _.clickNum
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default()), {
          type: "primary",
          size: "small",
          onClick: () => resetClick(_),
          children: "\u91CD\u7F6E"
        })]
      });
    }
  }, {
    title: "操作",
    key: "action",
    render: (_, record) => {
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_space__WEBPACK_IMPORTED_MODULE_6___default()), {
        size: "middle",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default()), {
          type: "primary",
          icon: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_11__.EditOutlined, {}),
          size: "small",
          onClick: () => showDrawer(_)
        })
      });
    }
  }];
  const data = lists.map((item, index) => {
    item.key = index;
    return item;
  }); // form
  // Form.Item 可以通过 dependencies 属性，设置关联字段。
  // 当关联字段的值发生变化时，会触发校验与更新。

  const [form] = antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().useForm();

  const onFinish = async values => {
    try {
      // 前端修改
      setLists(lists => {
        const newLists = lists.map((item, index) => {
          // 统一修改像素
          item.pixels = values.pixels; // 修改指定号信息

          if (index === values.key) {
            item.comment = values.comment;
            item.lineName = values.lineName;
          }

          return item;
        });
        return newLists;
      }); // 后端修改

      const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_9__/* .updatePixelsByDomainName */ .Ar)(_objectSpread(_objectSpread({}, values), {}, {
        domainName
      }));
      console.log("Success:", values, res);
      messageApi.open({
        type: "success",
        content: "修改成功"
      });
    } catch (error) {
      messageApi.open({
        type: "error",
        content: "修改失败，请重试"
      });
    } finally {
      onClose();
    }
  };

  const onFinishFailed = errorInfo => {
    console.log("Failed:", errorInfo);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
    style: {
      margin: "30px 50px"
    },
    children: [contextHolder, " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx("div", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("h1", {
        style: {
          textAlign: "center",
          padding: "20px",
          background: "#fafafa",
          borderBottom: "1px solid #ccc"
        },
        children: [dataLines.nation, " (", dataLines.userName, "--", dataLines.domainName, ")"]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_table__WEBPACK_IMPORTED_MODULE_2___default()), {
      columns: columns,
      dataSource: data,
      pagination: false
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)((antd_lib_drawer__WEBPACK_IMPORTED_MODULE_0___default()), {
      title: "\u4FEE\u6539",
      onClose: onClose,
      open: open,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
        style: {
          marginBottom: "20px"
        },
        children: ["ID: ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_tag__WEBPACK_IMPORTED_MODULE_5___default()), {
          children: dataLines._id
        }), "\u72B6\u6001\uFF1A", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_tag__WEBPACK_IMPORTED_MODULE_5___default()), {
          children: changeLine.status === 1 ? "上线" : "下线"
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default()), {
        // 当lineName变化时重新创建Form
        name: "basic",
        wrapperCol: {
          span: 16
        },
        style: {
          maxWidth: 600
        },
        initialValues: changeLine,
        onFinish: onFinish,
        onFinishFailed: onFinishFailed,
        autoComplete: "off",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().Item), {
          label: "\u7D22\u5F15\u503C",
          name: "key",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {
            disabled: true,
            style: {
              width: "40px"
            }
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().Item), {
          label: "\u5907\u6CE8",
          name: "comment",
          rules: [{
            required: true,
            message: "Please input your username!"
          }],
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {})
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().Item), {
          label: "\u53F7\u540D",
          name: "lineName",
          rules: [{
            required: true,
            message: "Please input your password!"
          }],
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {})
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().Item), {
          label: "\u50CF\u7D20",
          name: "pixels",
          rules: [{
            required: true,
            message: "Please input your password!"
          }],
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {})
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_3___default().Item), {
          label: null,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default()), {
            type: "primary",
            htmlType: "submit",
            children: "\u786E\u5B9A"
          })
        })]
      }, changeLine.lineName || "form")]
    })]
  });
} // 请求

async function getServerSideProps(context) {
  const {
    id = ""
  } = context.params;
  console.log("@@@", id); // 存储返回的后台数据

  let dataLines = null;

  try {
    // 发送请求：根据 id 获取问卷数据
    const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_9__/* .getQuestionByDomainName */ .xq)(id);
    dataLines = res.data[0];
  } catch (error) {
    console.error("获取数据失败", error);
    dataLines = {
      code: 1,
      msg: "数据获取失败"
    };
  }

  return {
    props: {
      dataLines,
      domainName: id
    }
  };
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 3800:
/***/ ((module) => {

module.exports = require("antd/lib/button");

/***/ }),

/***/ 8000:
/***/ ((module) => {

module.exports = require("antd/lib/drawer");

/***/ }),

/***/ 6190:
/***/ ((module) => {

module.exports = require("antd/lib/form");

/***/ }),

/***/ 675:
/***/ ((module) => {

module.exports = require("antd/lib/input");

/***/ }),

/***/ 7369:
/***/ ((module) => {

module.exports = require("antd/lib/message");

/***/ }),

/***/ 7374:
/***/ ((module) => {

module.exports = require("antd/lib/space");

/***/ }),

/***/ 2024:
/***/ ((module) => {

module.exports = require("antd/lib/switch");

/***/ }),

/***/ 4285:
/***/ ((module) => {

module.exports = require("antd/lib/table");

/***/ }),

/***/ 1886:
/***/ ((module) => {

module.exports = require("antd/lib/tag");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [226], () => (__webpack_exec__(1020)));
module.exports = __webpack_exports__;

})();