(() => {
var exports = {};
exports.id = 885;
exports.ids = [885];
exports.modules = {

/***/ 3364:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_question__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6240);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_question__WEBPACK_IMPORTED_MODULE_3__]);
_services_question__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const LkkButton = ({
  title,
  width,
  height,
  types,
  sizes,
  bgColor,
  color,
  lines = []
}) => {
  const {
    0: size,
    1: setSize
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(sizes); // default is 'middle'

  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const {
    id
  } = router.query; // 获取动态路由参数

  const floatBtnActions = {
    click: async () => {
      window.open(lines[0], "_self"); // 更新点击数量

      await (0,_services_question__WEBPACK_IMPORTED_MODULE_3__/* .updateClickNum */ .qi)(id, lines[0]);
    }
  };
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setSize(sizes);
  }, [sizes]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    style: {
      textAlign: "center"
    },
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("a", {
      onClick: floatBtnActions["click"],
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_0___default()), {
        type: types,
        size: size,
        style: {
          width: `${width}%`,
          height: `${height}px`,
          background: `${bgColor}`,
          color: `${color}`
        },
        children: title
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LkkButton);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZP": () => (/* binding */ QuestionCarousel_QuestionCarousel)
});

// UNUSED EXPORTS: Effect, Position

// EXTERNAL MODULE: external "antd/lib/config-provider"
var config_provider_ = __webpack_require__(2616);
var config_provider_default = /*#__PURE__*/__webpack_require__.n(config_provider_);
;// CONCATENATED MODULE: external "antd/lib/carousel"
const carousel_namespaceObject = require("antd/lib/carousel");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel_namespaceObject);
// EXTERNAL MODULE: external "antd/lib/image"
var image_ = __webpack_require__(8070);
var image_default = /*#__PURE__*/__webpack_require__.n(image_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/QuestionCompoents/QuestionCarousel/QuestionCarousel.tsx





let Position;

(function (Position) {
  Position["top"] = "top";
  Position["left"] = "left";
  Position["bottom"] = "bottom";
  Position["right"] = "right";
})(Position || (Position = {}));

let Effect;

(function (Effect) {
  Effect["scrollx"] = "scrollx";
  Effect["fade"] = "fade";
})(Effect || (Effect = {}));

// 轮播图
const QuestionCarousel = ({
  width,
  height,
  srcArr,
  autoplay,
  autoplaySpeed,
  arrows,
  dotPosition = Position.bottom,
  // 轮播方向
  effect = Effect.scrollx,
  // 动画效果函数
  arrowOffset,
  arrowSize,
  dotActiveWidth,
  dotHeight,
  dotWidth,
  dotGap,
  dotOffset,
  draggable,
  dots,
  colorBgContainer
}) => {
  // useEffect(() => {
  //   console.log(arrows);
  // }, []);
  const contentStyle = {
    margin: 0,
    height: "100%",
    color: "#fff",
    lineHeight: "160px",
    textAlign: "center",
    background: "#fff" // height: "100%",
    // width: "100%",
    // display: "inline-block",
    // textAlign: "center",
    // lineHeight: "50%",
    // color: "#000",
    // background: "rgb(236 236 236)",
    // overflow: "hidden",

  };
  const imgStyle = {
    height: height + "px",
    width: width + "px",
    display: "inline-block",
    textAlign: "center",
    color: "#000",
    background: "rgb(236 236 236)"
  };
  return /*#__PURE__*/jsx_runtime_.jsx((config_provider_default()), {
    theme: {
      components: {
        Carousel: {
          /* 这里是你的组件 token */
          arrowOffset,
          arrowSize,
          dotActiveWidth,
          dotHeight,
          dotWidth,
          dotGap,
          dotOffset,
          colorBgContainer,
          // 组件的容器背景色，例如：默认按钮、输入框等
          colorText: "#000"
        }
      }
    },
    children: /*#__PURE__*/jsx_runtime_.jsx((carousel_default()), {
      dotPosition: dotPosition,
      effect: effect,
      autoplay: autoplay,
      autoplaySpeed: autoplaySpeed * 1000,
      arrows: arrows,
      infinite: true,
      draggable: draggable,
      dots: dots,
      children: srcArr?.map((src, index) => {
        const {
          url
        } = src;
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
            style: contentStyle,
            children: /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
              style: imgStyle,
              src: url,
              preview: false,
              alt: ""
            })
          })
        }, index);
      })
    })
  });
};

/* harmony default export */ const QuestionCarousel_QuestionCarousel = (QuestionCarousel);

/***/ }),

/***/ 4385:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8678);
/* harmony import */ var _QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);






// 单选框
const QuestionCheckbox = ({
  fe_id,
  props
}) => {
  const {
    title,
    isVertical,
    list,
    isWrap,
    color
  } = props; // 收集多选项

  const {
    0: selectedValue,
    1: setSelectedValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]); // 初始化时，判断默认选中

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    list.forEach(item => {
      const {
        value,
        checked
      } = item;

      if (checked) {
        setSelectedValue(selectedValue => {
          return selectedValue.concat(value);
        });
      }
    });
  }, [list]); // 切换选中

  function toggleChecked(value) {
    // includes判断数组中是否存在：返回布尔值
    const isChecked = selectedValue.includes(value);

    if (isChecked) {
      setSelectedValue(selectedValue => // 已经存在,筛选掉
      selectedValue.filter(item => item !== value));
    } else {
      // 否则，添加
      setSelectedValue(selectedValue.concat(value));
    }
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("strong", {
      style: {
        color,
        fontSize: "14px",
        display: "block",
        marginBottom: "5px"
      },
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
      type: "hidden",
      name: fe_id,
      value: selectedValue.toString()
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("ul", {
      className: (_QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2___default().list),
      style: {
        display: "flex",
        flexWrap: isWrap ? "wrap" : "nowrap",
        justifyContent: "start",
        marginLeft: "-3px"
      },
      children: list.map(opt => {
        const {
          value: val,
          text
        } = opt; // 判断垂直、水平

        let clasName = "";
        if (isVertical) clasName = (_QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2___default().vertivalItem);else clasName = (_QuestionCheckbox_module_scss__WEBPACK_IMPORTED_MODULE_2___default().horizontalItem);
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("li", {
          className: clasName,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("label", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              type: "checkbox",
              checked: selectedValue.includes(val),
              onChange: () => toggleChecked(val)
            }), text]
          })
        }, val);
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionCheckbox);

/***/ }),

/***/ 1489:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8070);
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_image__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_question__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6240);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_question__WEBPACK_IMPORTED_MODULE_2__]);
_services_question__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



 // 定义FloatButton悬浮按钮属性





const LkkFloatButton = ({
  width,
  height = 0,
  left,
  top,
  description,
  isCenter,
  color,
  borderRadius,
  background,
  backgroundImage,
  zIndex = 1,
  position,
  fontSize,
  // onFloatBtnName,
  lines = []
}) => {
  // 获取动态路由参数
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  const {
    id
  } = router.query; // 事件对象

  const floatBtnActions = {
    click: async () => {
      window.open(lines[0], "_self"); // 更新点击数量

      await (0,_services_question__WEBPACK_IMPORTED_MODULE_2__/* .updateClickNum */ .qi)(id, lines[0]);
    }
  }; // 位置样式

  const {
    0: postionStyle,
    1: setPostionStyle
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
    fontSize: `${fontSize}px`,
    position: "fixed",
    width: "0px",
    // 初始值可以是任何值
    height: "0px",
    zIndex,
    top: "0px",
    left: "0px"
  });
  const {
    0: windowWidth,
    1: setWindowWidth
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
  const {
    0: windowHeight,
    1: setWindowHeight
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0); // 获取窗口宽度和高度

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    const updateWindowSize = () => {
      setWindowWidth(window.innerWidth);
      setWindowHeight(window.innerHeight);
    }; // 初始化时调用一次


    updateWindowSize(); // 添加监听事件

    window.addEventListener("resize", updateWindowSize); // 清除监听事件

    return () => {
      window.removeEventListener("resize", updateWindowSize);
    };
  }, []); // 根据窗口宽度和高度以及 position 更新样式

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    let updatedStyle = _objectSpread({}, postionStyle);

    switch (position) {
      case "custom":
        // console.log(top, left, width, height);
        updatedStyle = _objectSpread(_objectSpread({}, updatedStyle), {}, {
          top: `${top}px`,
          left: `${left}px`,
          width: `${width}px`,
          height: `${height}px`
        });
        break;

      case "top":
        updatedStyle = _objectSpread(_objectSpread({}, updatedStyle), {}, {
          top: "0px",
          left: "0px",
          width: `${windowWidth}px`,
          height: `${height}px`
        });
        break;

      case "left":
        updatedStyle = _objectSpread(_objectSpread({}, updatedStyle), {}, {
          top: `${windowHeight - height}px`,
          left: "0px",
          width: `${windowWidth}px`,
          height: `${height}px`
        });
        break;

      default:
        updatedStyle = _objectSpread(_objectSpread({}, updatedStyle), {}, {
          top: "0px",
          left: "0px"
        });
    }

    setPostionStyle(updatedStyle);
  }, [position, windowWidth, windowHeight, width, height, top, left]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    style: postionStyle,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("a", {
      style: {
        width: "100%",
        height: "100%",
        display: "flex",
        justifyContent: isCenter ? "center" : "start",
        alignItems: "center",
        color: color,
        borderRadius: borderRadius,
        background: background,
        boxShadow: "0px 0px 10px 2px #a19d9d",
        overflow: "hidden"
      } // onClick={btn}
      ,
      onClick: floatBtnActions["click"],
      children: [!backgroundImage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.Fragment, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          children: description
        })
      }), backgroundImage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((antd_lib_image__WEBPACK_IMPORTED_MODULE_0___default()), {
        alt: "",
        width: position === "custom" ? width : "100%",
        height: height,
        src: backgroundImage,
        preview: false
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LkkFloatButton);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2133:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ QuestionImage_QuestionImage)
});

// EXTERNAL MODULE: external "antd/lib/image"
var image_ = __webpack_require__(8070);
var image_default = /*#__PURE__*/__webpack_require__.n(image_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "ahooks"
const external_ahooks_namespaceObject = require("ahooks");
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/QuestionCompoents/QuestionImage/QuestionImage.tsx





const QuestionImage = props => {
  // 默认属性 与 props合并
  const {
    src,
    width,
    height,
    isCenter,
    border,
    borderRadius,
    placeholder
  } = props;
  const imgRef = (0,external_react_.useRef)(null); // 使用 div 作为外层容器

  const {
    0: loaded,
    1: setLoaded
  } = (0,external_react_.useState)(false);
  const [inViewport] = (0,external_ahooks_namespaceObject.useInViewport)(imgRef); // 判断组件是否进入可视口

  (0,external_react_.useEffect)(() => {
    console.log(inViewport);
  }, [inViewport]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    ref: imgRef,
    style: {
      width: "100%",
      height,
      display: "flex",
      justifyContent: "center",
      alignItems: "center" // backgroundColor: "#eee",

    },
    children: /*#__PURE__*/jsx_runtime_.jsx((image_default()), {
      width: width,
      height: height,
      style: {
        border: `${border}px solid #ccc`,
        borderRadius: `${borderRadius}px`,
        padding: border ? "3px" : "0px",
        opacity: loaded ? 1 : 0.5,
        // 过渡效果
        transition: "opacity 0.5s ease-in-out"
      },
      placeholder: loaded // antd 自带 loading 效果
      ,
      src: inViewport ? src : "https://266aaa111.shop:9902/uploads/loading.png" // 进入视口才加载真实图片
      ,
      onLoad: () => setLoaded(true) // preview={{ visible: false }} // 可选：如果不需要 antd 预览功能
      // alt="loading"

    })
  });
};

/* harmony default export */ const QuestionImage_QuestionImage = (QuestionImage);

/***/ }),

/***/ 9319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8168);
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const {
  Title,
  Paragraph
} = (antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default());

const QuestionInfo = props => {
  const {
    title,
    desc,
    descColor,
    titleColor
  } = props; // // 处理换行
  // const descTextList = desc?.split('\n') || []
  // return <div style={{textAlign:'center'}}>
  //   <h1 style={{color:titleColor}}>{title}</h1>
  //   <p style={{color:descColor}}>
  //     {descTextList.map((t, index) => (
  //       <span key={index}>
  //         {index > 0 && <br />}
  //         {t}
  //       </span>
  //     ))}
  //   </p>
  // </div>
  // 处理换行

  const descTextList = desc?.split("\n") || [];
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    style: {
      textAlign: "center"
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Title, {
      style: {
        fontSize: "24px",
        color: titleColor
      },
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Paragraph, {
      style: {
        color: descColor,
        marginBottom: 0
      },
      children: descTextList.map((t, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("span", {
        children: [index > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("br", {}), t]
      }, index))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionInfo);

/***/ }),

/***/ 9599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_flex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3754);
/* harmony import */ var antd_lib_flex__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_flex__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);


 // import styles from "./QuestionInput.module.scss";
// 引入Antd组件




/**
 * 输入框
 * @param fe_id 输入框组件的id
 * @param props 输入框组件的props
 * @returns
 */
const QuestionInput = ({
  fe_id,
  props
}) => {
  const {
    title,
    placeholder,
    color,
    layout
  } = props; // 利用普通方式实现
  // return <>
  //   <p style={{color:color}}>{title}</p>
  //   <div className={styles.inputWrapper}>
  //     {/* 将组件的fe_id 作为表单项的key值 */}
  //     <input name={fe_id} placeholder={placeholder} />
  //   </div>
  // </>
  // 利用antd组件方式实现

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)((antd_lib_flex__WEBPACK_IMPORTED_MODULE_0___default()), {
    vertical: layout === "vertical",
    justify: layout === "vertical" ? "" : "start",
    align: layout !== "vertical" ? "center" : "",
    gap: 5,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      style: {
        color: color,
        fontWeight: "bold",
        fontSize: "14px"
      },
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      style: {
        display: "flex",
        flex: "1"
      },
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {
        name: fe_id,
        placeholder: placeholder
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionInput);

/***/ }),

/***/ 8098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ QuestionList)
});

;// CONCATENATED MODULE: external "antd/lib/divider"
const divider_namespaceObject = require("antd/lib/divider");
var divider_default = /*#__PURE__*/__webpack_require__.n(divider_namespaceObject);
// EXTERNAL MODULE: external "antd/lib/list"
var list_ = __webpack_require__(4779);
var list_default = /*#__PURE__*/__webpack_require__.n(list_);
// EXTERNAL MODULE: external "antd/lib/avatar"
var avatar_ = __webpack_require__(5998);
var avatar_default = /*#__PURE__*/__webpack_require__.n(avatar_);
// EXTERNAL MODULE: external "antd/lib/space"
var space_ = __webpack_require__(7374);
var space_default = /*#__PURE__*/__webpack_require__.n(space_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/QuestionCompoents/QuestionList/QuestionList.tsx










const LkkList = ({
  itemLayout = "vertical",
  href,
  title,
  avatar,
  description,
  content,
  srcArr,
  imgWidth,
  imgHeight,
  star = 0,
  like = 0,
  message = 0
}) => {
  const IconText = ({
    icon,
    text
  }) => /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: {
      margin: "10px 0 "
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)((space_default()), {
      children: [/*#__PURE__*/external_react_default().createElement(icon), text]
    })
  });

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((list_default()), {
      itemLayout: itemLayout,
      size: "large",
      dataSource: [{
        href,
        title,
        avatar,
        description,
        content
      }],
      renderItem: item => /*#__PURE__*/(0,jsx_runtime_.jsxs)((list_default()).Item, {
        style: {
          flexWrap: itemLayout === "horizontal" ? "wrap" : "nowrap"
        },
        actions: [/*#__PURE__*/jsx_runtime_.jsx(IconText, {
          icon: icons_.StarOutlined,
          text: star.toString()
        }, "list-vertical-star-o"), /*#__PURE__*/jsx_runtime_.jsx(IconText, {
          icon: icons_.LikeOutlined,
          text: like.toString()
        }, "list-vertical-like-o"), /*#__PURE__*/jsx_runtime_.jsx(IconText, {
          icon: icons_.MessageOutlined,
          text: message.toString()
        }, "list-vertical-message")],
        extra: /*#__PURE__*/jsx_runtime_.jsx("div", {
          style: {
            width: "100%",
            textAlign: "center",
            display: "flex",
            justifyContent: "space-around",
            flexWrap: itemLayout === "horizontal" ? "wrap" : "nowrap"
          },
          children: srcArr?.map(({
            url
          }, index) => /*#__PURE__*/jsx_runtime_.jsx("img", {
            style: {
              margin: "5px 0",
              border: "1px solid #ccc"
            },
            width: imgWidth,
            height: imgHeight,
            alt: "logo",
            src: url
          }, index))
        }),
        children: [/*#__PURE__*/jsx_runtime_.jsx((list_default()).Item.Meta, {
          avatar: /*#__PURE__*/jsx_runtime_.jsx((avatar_default()), {
            src: item.avatar
          }),
          title: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: item.href,
            children: item.title
          }),
          description: item.description
        }), item.content]
      }, item.title)
    }), /*#__PURE__*/jsx_runtime_.jsx((divider_default()), {
      style: {
        margin: "0"
      }
    })]
  });
};

/* harmony default export */ const QuestionList = (LkkList);

/***/ }),

/***/ 6053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8168);
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const {
  Paragraph
} = (antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default());

const QuestionParagrapg = props => {
  const {
    text,
    isCenter,
    color,
    borderRadius,
    background,
    textIndext,
    fontWeight,
    fontSize,
    lineHeight,
    italic
  } = props; //  样式
  // const style: CSSProperties = {
  //   color,
  //   borderRadius,
  //   background,
  // };
  // // 是否居中
  // if (isCenter) style.textAlign = "center";
  // // 处理换行
  // const textList = text?.split("\n") || [];
  // return (
  //   <p style={style}>
  //     {textList.map((t, index) => (
  //       <span key={index}>
  //         {index > 0 && <br />}
  //         {t}
  //       </span>
  //     ))}
  //   </p>
  // );
  // 处理换行

  const textList = text?.split("\n") || [];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Paragraph, {
    italic: italic,
    style: {
      textAlign: isCenter && textIndext === 0 ? "center" : "justify",
      marginBottom: "0px",
      color: `${color}`,
      borderRadius,
      background,
      textIndent: `${textIndext}em`,
      fontWeight: fontWeight ? "bold" : "400",
      fontSize: `${fontSize}px`,
      lineHeight
    },
    children: textList.map((t, index) => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("span", {
      children: [index > 0 && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("br", {}), t]
    }, index))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionParagrapg);

/***/ }),

/***/ 8714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ QuestionRadio_QuestionRadio)
});

// EXTERNAL MODULE: external "antd/lib/config-provider"
var config_provider_ = __webpack_require__(2616);
var config_provider_default = /*#__PURE__*/__webpack_require__.n(config_provider_);
// EXTERNAL MODULE: external "antd/lib/space"
var space_ = __webpack_require__(7374);
var space_default = /*#__PURE__*/__webpack_require__.n(space_);
;// CONCATENATED MODULE: external "antd/lib/radio"
const radio_namespaceObject = require("antd/lib/radio");
var radio_default = /*#__PURE__*/__webpack_require__.n(radio_namespaceObject);
// EXTERNAL MODULE: external "antd/lib/typography"
var typography_ = __webpack_require__(8168);
var typography_default = /*#__PURE__*/__webpack_require__.n(typography_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/QuestionCompoents/QuestionRadio/QuestionRadio.tsx




 // import styles from "./QuestionRadio.module.scss";



const {
  Paragraph
} = (typography_default());

// 单选框
const QuestionRadio = ({
  fe_id,
  props
}) => {
  const {
    title,
    isVertical,
    value,
    options,
    isWrap,
    optionType = "button",
    color,
    buttonBg,
    buttonColor,
    buttonSolidCheckedBg,
    buttonSolidCheckedColor
  } = props;
  (0,external_react_.useEffect)(() => {// console.log(optionType);
  }, []); // 选中：利用普通方式实现
  // const [gender, setGender] = useState(value);
  // function handleRadioChange(event: ChangeEvent<HTMLInputElement>) {
  //   setGender(event.target.value);
  // }
  // 选中：利用antd组件方式实现

  const {
    0: radioValue,
    1: setRadioValue
  } = (0,external_react_.useState)(value);

  const onChange = e => {
    // console.log("radio checked", e.target.value);
    setRadioValue(e.target.value);
  };

  return (
    /*#__PURE__*/
    // 利用普通方式实现
    // <>
    //   <p>{title}</p>
    //   <ul className={styles.list}>
    //     {options.map((opt) => {
    //       const { value: val, text } = opt;
    //       // 判断垂直、水平
    //       let clasName = "";
    //       if (isVertical) clasName = styles.vertivalItem;
    //       else clasName = styles.horizontalItem;
    //       return (
    //         <li key={val} className={clasName}>
    //           <label>
    //             <input
    //               type="radio" // 单选
    //               name={fe_id} // 分组名称
    //               value={val} // 值
    //               checked={val === gender} // 判断选中
    //               // defaultChecked={val === value}
    //               onChange={handleRadioChange}
    //             />
    //             {text}
    //           </label>
    //         </li>
    //       );
    //     })}
    //   </ul>
    // </>
    // 利用antd组件方式实现
    (0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/jsx_runtime_.jsx(Paragraph, {
        strong: true,
        style: {
          color,
          marginBottom: "3px"
        },
        children: title
      }), /*#__PURE__*/jsx_runtime_.jsx((config_provider_default()), {
        theme: {
          components: {
            Radio: {
              /* 这里是你的组件 token */
              buttonBg,
              //单选框按钮背景色
              buttonColor,
              // 单选框按钮文本颜色
              buttonSolidCheckedBg,
              buttonSolidCheckedHoverBg: buttonSolidCheckedBg,
              buttonSolidCheckedActiveBg: buttonSolidCheckedBg,
              //单选框实色按钮选中时的背景色
              buttonSolidCheckedColor //单选框实色按钮选中时的文本颜色

            }
          }
        },
        children: /*#__PURE__*/jsx_runtime_.jsx((radio_default()).Group, {
          value: radioValue,
          optionType: optionType,
          buttonStyle: "solid",
          onChange: onChange,
          name: fe_id,
          children: /*#__PURE__*/jsx_runtime_.jsx((space_default()), {
            direction: isVertical ? "vertical" : "horizontal",
            style: {
              display: "flex",
              flexWrap: isWrap ? "wrap" : "nowrap",
              justifyContent: "start"
            },
            children: options.map(opt => {
              const {
                value,
                text
              } = opt;
              return /*#__PURE__*/jsx_runtime_.jsx((radio_default()), {
                value: value,
                style: {
                  fontSize: "13px"
                },
                children: text
              }, value);
            })
          })
        })
      })]
    })
  );
};

/* harmony default export */ const QuestionRadio_QuestionRadio = (QuestionRadio);

/***/ }),

/***/ 5890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const LkkSpace = ({
  height
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    style: {
      width: "100%",
      height: `${height}px`,
      background: "#fff"
    }
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LkkSpace);

/***/ }),

/***/ 1025:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8168);
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_typography__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);


 // import styles from "./QuestionTextarea.module.scss";



const {
  Paragraph
} = (antd_lib_typography__WEBPACK_IMPORTED_MODULE_1___default());
const {
  TextArea
} = (antd_lib_input__WEBPACK_IMPORTED_MODULE_0___default());

const QuestionTextarea = ({
  fe_id,
  props
}) => {
  const {
    title,
    placeholder,
    color,
    maxLength
  } = props; // return <>
  //   <p style={{color}}>{title}</p>
  //   <div className={styles.textAreaWrapper}>
  //     <textarea name={fe_id} placeholder={placeholder} rows={5}></textarea>
  //   </div>
  // </>

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(Paragraph, {
      strong: true,
      style: {
        color: color,
        marginBottom: "5px"
      },
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(TextArea, {
        name: fe_id,
        placeholder: placeholder,
        showCount: true,
        maxLength: maxLength,
        autoSize: {
          minRows: 2,
          maxRows: 6
        }
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionTextarea);

/***/ }),

/***/ 6775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8168);
/* harmony import */ var antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_typography__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);

 // 引入Antd组件


const {
  Title
} = (antd_lib_typography__WEBPACK_IMPORTED_MODULE_0___default());

const QuestionTitle = props => {
  const {
    text,
    level,
    isCenter,
    color
  } = props; // // 样式
  // const style: CSSProperties = {}
  // // 是否居中
  // if(isCenter) style.textAlign = 'center'
  // // 字体颜色
  // if(color) style.color = color
  // if(level === 1) return <h1 style={style}>{text}</h1>
  // if(level === 2) return <h2 style={style}>{text}</h2>
  // if(level === 3) return <h3 style={style}>{text}</h3>
  // if(level === 4) return <h4 style={style}>{text}</h4>
  // if(level === 5) return <h5 style={style}>{text}</h5>
  // // 兜底
  // return null

  const genFontSize = level => {
    if (level === 1) return "32px";
    if (level === 2) return "28px";
    if (level === 3) return "24px";
    if (level === 4) return "20px";
    if (level === 5) return "16px";
    return "12px";
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(Title, {
    level: level,
    style: {
      textAlign: isCenter ? "center" : "start",
      marginBottom: "0",
      fontSize: genFontSize(level),
      color: color
    },
    children: text
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QuestionTitle);

/***/ }),

/***/ 7377:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var plyr_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2065);
/* harmony import */ var plyr_react_plyr_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2327);
/* harmony import */ var plyr_react_plyr_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(plyr_react_plyr_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([plyr_react__WEBPACK_IMPORTED_MODULE_1__]);
plyr_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







const LkkVideo = props => {
  const {
    url = "",
    autoplay,
    poster
  } = props; // console.log(autoplay);
  // 视频封面

  const {
    0: videoPoster,
    1: setvideoPoster
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(); // 引用播放器实例

  const playerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null); // 获取视频某一帧

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const video = document.createElement("video");
    video.crossOrigin = "anonymous"; // 设置跨域

    video.src = url; // 你的视频地址

    const handleLoadedData = () => {
      // 确保视频已经加载完成
      video.currentTime = 0; // 跳到视频开始处
    };

    const handleSeeked = () => {
      // 视频暂停并跳到第一帧后，绘制第一帧到 canvas
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");

      if (ctx) {
        // 设置 canvas 大小为视频的宽高
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight; // 将第一帧绘制到 canvas 上

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height); // 将 canvas 转为图片数据 URL

        const imageUrl = canvas.toDataURL("image/jpeg");
        setvideoPoster(imageUrl); // 设置 poster
      }
    };

    video.addEventListener("loadeddata", handleLoadedData);
    video.addEventListener("seeked", handleSeeked);
    return () => {
      // 清理事件监听器和 DOM 元素
      video.removeEventListener("loadeddata", handleLoadedData);
      video.removeEventListener("seeked", handleSeeked);
    };
  }, []); // 配置 Plyr 的视频选项

  const videoSource = {
    type: "video",
    title: "Example Video",
    // 可选，设置视频标题
    sources: [{
      src: url,
      // 视频地址
      type: "video/mp4",
      // 视频类型
      size: 720 // 可选，视频分辨率

    }],
    poster: poster ? poster : videoPoster // 视频封面

  }; // 使用类型断言为视频元素添加下载属性

  const videoOptions = _objectSpread(_objectSpread({}, videoSource), {}, {
    download: "example-video.mp4" // 下载文件名

  });

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(plyr_react__WEBPACK_IMPORTED_MODULE_1__["default"], {
      ref: playerRef,
      source: videoOptions,
      options: {
        controls: ["play-large", // 中间的大播放按钮
        "play", // 播放/暂停按钮
        "progress", //播放进度条
        "current-time", //当前播放时间显示
        "duration", //视频总时长显示
        "mute", //静音按钮
        // 'volume', //音量调节滑块
        "settings", // 设置按钮
        // 'pip', // 画中画模式（部分浏览器支持）
        // 'airplay', // AirPlay 按钮（仅支持 Safari）
        "fullscreen" //全屏切换按钮
        // 'download', // 视频下载按钮
        // 'captions', // 字幕按钮
        // 'remaining-time', //剩余时间显示
        ],
        autoplay,
        muted: true,
        loop: {
          active: true
        },
        // 启用循环播放
        speed: {
          selected: 1,
          options: [0.5, 1, 1.5, 2, 2.5, 3]
        },
        // 设置播放速
        i18n: {
          speed: "播放速度",
          // 控件名称
          normal: "正常" // 默认速度

        },
        ratio: "12:9",
        // 宽高比
        captions: {
          active: true,
          language: "zh"
        }
      } // onPlay={handlePlay} // 视频开始播放
      // onPause={handlePause} // 视频暂停播放

    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LkkVideo);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9816:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ getComponent)
/* harmony export */ });
/* harmony import */ var _QuestionInput_QuestionInput__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9599);
/* harmony import */ var _QuestionRadio_QuestionRadio__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8714);
/* harmony import */ var _QuestionTitle_QuestionTitle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6775);
/* harmony import */ var _QuestionParagraph_QuestionParagraph__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6053);
/* harmony import */ var _QuestionInfo_QuestionInfo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9319);
/* harmony import */ var _QuestionTextarea_QuestionTextarea__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1025);
/* harmony import */ var _QuestionCheckbox_QuestionCheckbox__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4385);
/* harmony import */ var _QuestionCarousel_QuestionCarousel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8766);
/* harmony import */ var _QuestionImage_QuestionImage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2133);
/* harmony import */ var _QuestionFloatButton_QuestionFloatButton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1489);
/* harmony import */ var _QuestionButton_QuestionButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3364);
/* harmony import */ var _QuestionSpace_QuestionSpace__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5890);
/* harmony import */ var _QuestionList_QuestionList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8098);
/* harmony import */ var _QuestionVideo_QuestionVideo__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7377);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_QuestionFloatButton_QuestionFloatButton__WEBPACK_IMPORTED_MODULE_9__, _QuestionButton_QuestionButton__WEBPACK_IMPORTED_MODULE_10__, _QuestionVideo_QuestionVideo__WEBPACK_IMPORTED_MODULE_13__]);
([_QuestionFloatButton_QuestionFloatButton__WEBPACK_IMPORTED_MODULE_9__, _QuestionButton_QuestionButton__WEBPACK_IMPORTED_MODULE_10__, _QuestionVideo_QuestionVideo__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

// 输入框组件
 // 单选框组件

 // 标题组件

 // 一行段落组件

 // 问卷标题组件

 // 多行输入组件

 // 多选框组件

 // 轮播图









const getComponent = (comp, checkeLines) => {
  const {
    fe_id,
    type,
    isHidden,
    props
  } = comp; // console.log(checkeLines);

  const lines = checkeLines.map(line => line.link);
  if (isHidden) return null; // 输入框

  if (type === "questionInput") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionInput_QuestionInput__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
      fe_id: fe_id,
      props: props
    });
  } // 单选框


  if (type === "questionRadio") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionRadio_QuestionRadio__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      fe_id: fe_id,
      props: props
    });
  } // 标题


  if (type === "questionTitle") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionTitle_QuestionTitle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 一行段落


  if (type === "questionParagraph") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionParagraph_QuestionParagraph__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 问卷标题


  if (type === "questionInfo") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionInfo_QuestionInfo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 多行输入


  if (type === "questionTextarea") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionTextarea_QuestionTextarea__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      fe_id: fe_id,
      props: props
    });
  } // 多选框


  if (type === "questionCheckbox") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionCheckbox_QuestionCheckbox__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      fe_id: fe_id,
      props: props
    });
  } // 轮播图


  if (type === "questionCarousel") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionCarousel_QuestionCarousel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, _objectSpread({}, props));
  } // 图片


  if (type === "questionImage") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionImage_QuestionImage__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 浮动按钮


  if (type === "H5FloatButton") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionFloatButton_QuestionFloatButton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, _objectSpread(_objectSpread({}, props), {}, {
      lines: lines
    }));
  } //普通按钮


  if (type === "LkkButton") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionButton_QuestionButton__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, _objectSpread(_objectSpread({}, props), {}, {
      lines: lines
    }));
  } // 间隔


  if (type === "H5Space") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionSpace_QuestionSpace__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 列表


  if (type === "H5List") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionList_QuestionList__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, _objectSpread({}, props));
  } // 视频


  if (type === "LkkVideo") {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_14__.jsx(_QuestionVideo_QuestionVideo__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, _objectSpread({}, props));
  }
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9523:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Question),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var antd_lib_spin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(261);
/* harmony import */ var antd_lib_spin__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_spin__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1030);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_list__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4779);
/* harmony import */ var antd_lib_list__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_list__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_avatar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5998);
/* harmony import */ var antd_lib_avatar__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_avatar__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_Question_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5544);
/* harmony import */ var _styles_Question_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_Question_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _services_question__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6240);
/* harmony import */ var _components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2480);
/* harmony import */ var _components_QuestionCompoents__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9816);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9648);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_question__WEBPACK_IMPORTED_MODULE_5__, _components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__, _components_QuestionCompoents__WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_9__]);
([_services_question__WEBPACK_IMPORTED_MODULE_5__, _components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__, _components_QuestionCompoents__WEBPACK_IMPORTED_MODULE_7__, axios__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












 // 上线的line类型数据




function Question(props) {
  const {
    code,
    data,
    msg
  } = props.data;
  console.log(props.data);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)(); // 屏蔽器数据

  const {
    0: ipCloakData,
    1: setIpCloakData
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(undefined); // 加载中...

  const {
    0: loading,
    1: setLoading
  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true); // 用于控制加载状态

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    // 发起请求
    axios__WEBPACK_IMPORTED_MODULE_9__["default"].get("https://266aaa111.shop:9902/api/maxmind").then(response => {
      console.log(response.data);
      setIpCloakData(response.data); // 设置返回数据
    }).catch(error => {
      console.error("请求错误:", error);
    }).finally(() => {
      setLoading(false); // 无论请求成功还是失败，都会更新加载状态
    });
  }, []); // 空依赖数组，表示只在组件挂载时发起请求

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(() => {
    console.log("@@", "production", "https://000america.shop:3000");
  }, []);
  const {
    fe_id,
    title = "",
    isDeleted,
    isPublished,
    desc,
    componentList = [],
    css,
    js
  } = data || {};

  const handleRedirect = () => {
    router.push("/success"); // 跳转到 /success 页面
  }; // 数据错误


  if (code !== 0) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      title: "\u9519\u8BEF",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("h1", {
        children: "\u9519\u8BEF"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("p", {
        children: msg
      })]
    });
  } // 已删除的问卷,提示错误


  if (isDeleted) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      title: title,
      desc: desc,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("h1", {
        children: title
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("p", {
        children: "\u8BE5\u95EE\u5377\u5DF2\u7ECF\u88AB\u5220\u9664"
      })]
    });
  } // 尚未发布的问卷，提示错误


  if (!isPublished) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(_components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
      title: title,
      desc: desc,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("h1", {
        children: title
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("p", {
        children: "\u8BE5\u95EE\u5377\u5C1A\u672A\u53D1\u5E03"
      })]
    });
  } // 遍历组件


  const ComponentList = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
    children: componentList.map(c => {
      const Component = (0,_components_QuestionCompoents__WEBPACK_IMPORTED_MODULE_7__/* .getComponent */ .X)(c, props.checkeLines);
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("div", {
        style: {
          marginBottom: "16px"
        },
        children: Component
      }, c.fe_id);
    })
  }); // 使用映射对象简化语言匹配逻辑


  const languageMap = {
    CN: ["zh", "zh-CN"],
    KR: ["ko", "ko-KR"],
    JP: ["ja", "ja-JP"],
    US: ["en", "en-US"]
  }; // 优化语言匹配函数

  const isLanguage = (user_language, country_code, language) => {
    if (!user_language) return true; // 如果用户未启用语言过滤，直接返回 true
    // 使用映射对象检查国家和语言是否匹配

    const validLanguages = languageMap[country_code] || [];
    return validLanguages.includes(language);
  }; // 合并和优化逻辑判断


  const real = () => {
    const {
      country_code,
      device_type,
      language,
      isKnown,
      is_proxy,
      is_vpn,
      is_tor,
      VPN
    } = ipCloakData;
    const {
      country_code: user_country_code,
      device_type: user_device_type,
      ipCloak,
      isVPNOrProxy,
      language: user_language
    } = props.ipCloaks;
    console.log(props.ipCloaks); // 判断是否需要阻止访问（有VPN/代理/TOR等）

    const isBlockedByVPNOrProxy = isVPNOrProxy && (isKnown || is_proxy || is_vpn || is_tor || VPN);
    if (isBlockedByVPNOrProxy) return false; // 判断是否启用了屏蔽器，并且用户IP属于允许访问的国家且语言匹配

    if (ipCloak && user_country_code.length > 0) {
      const isCountryValid = user_country_code.includes(country_code);
      const isLanguageValid = isLanguage(user_language, country_code, language);

      if (isCountryValid && isLanguageValid) {
        // 判断设备类型
        if (user_device_type) {
          return device_type === "mobile";
        } else {
          return true; // 渲染真实页面
        }
      }

      return false; // 渲染假页面
    }

    return true; // 渲染真实页面
  };

  const listData = Array.from({
    length: 3
  }).map((_, i) => ({
    href: "https://ant.design",
    title: `ant design part ${i + 1}`,
    avatar: `https://api.dicebear.com/7.x/miniavs/svg?seed=${i}`
  })); // 页面加载状态，等待数据加载完成

  if (loading) {
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.Fragment, {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_list__WEBPACK_IMPORTED_MODULE_2___default()), {
        itemLayout: "vertical",
        size: "large",
        dataSource: listData,
        renderItem: item => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_list__WEBPACK_IMPORTED_MODULE_2___default().Item), {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_1___default()), {
            loading: loading,
            active: true,
            avatar: true,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_list__WEBPACK_IMPORTED_MODULE_2___default().Item.Meta), {
              avatar: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_avatar__WEBPACK_IMPORTED_MODULE_3___default()), {
                src: item.avatar
              }),
              title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("a", {
                href: item.href,
                children: item.title
              })
            })
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("div", {
        style: {
          textAlign: "center",
          margin: "auto"
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx((antd_lib_spin__WEBPACK_IMPORTED_MODULE_0___default()), {
          indicator: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_10__.LoadingOutlined, {
            spin: true
          }),
          size: "large"
        })
      })]
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx(_components_PageWrapper__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
    title: title,
    id: fe_id,
    desc: desc,
    css: css,
    js: js,
    lines: props.checkeLines,
    children: real() ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("form", {
      method: "post",
      action:  false ? 0 : `${"https://000america.shop:3000"}/api/answer`,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("input", {
        type: "hidden",
        name: "questionId",
        defaultValue: fe_id
      }), ComponentList, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("div", {
        className: (_styles_Question_module_scss__WEBPACK_IMPORTED_MODULE_12___default().submitBtnContainer),
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("button", {
          type: "submit",
          children: "\u63D0\u4EA4"
        })
      })]
    }) :
    /*#__PURE__*/
    // 假页面
    (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("div", {
      style: {
        width: "100%",
        margin: "10% auto 0",
        backgroundColor: "#f0f0f0",
        borderRadius: "10px"
      },
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("h1", {
        style: {
          paddingLeft: "2% "
        },
        children: "\u606D\u559C, \u7AD9\u70B9\u521B\u5EFA\u6210\u529F\uFF01"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("h3", {
        style: {
          paddingLeft: "2% "
        },
        children: "\u8FD9\u662F\u9ED8\u8BA4index.html\uFF0C\u672C\u9875\u9762\u7531\u7CFB\u7EDF\u81EA\u52A8\u751F\u6210"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsxs)("ul", {
        style: {
          paddingLeft: "20px"
        },
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("li", {
          style: {
            lineHeight: 2.3
          },
          children: "\u672C\u9875\u9762\u5728FTP\u6839\u76EE\u5F55\u4E0B\u7684index.html"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("li", {
          style: {
            lineHeight: 2.3
          },
          children: "\u60A8\u53EF\u4EE5\u4FEE\u6539\u3001\u5220\u9664\u6216\u8986\u76D6\u672C\u9875\u9762"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_11__.jsx("li", {
          style: {
            lineHeight: 2.3
          },
          children: "FTP\u76F8\u5173\u4FE1\u606F\uFF0C\u8BF7\u5230\u201C\u9762\u677F\u7CFB\u7EDF\u540E\u53F0 \u300B FTP\u201D \u67E5\u770B"
        })]
      })]
    })
  });
} // 请求
// eslint-disable-next-line @typescript-eslint/no-explicit-any

async function getServerSideProps(context) {
  const {
    id = ""
  } = context.params; // 存储画页信息

  let data = null; // 存储上线的链接数组

  let checkeLines = []; // 存储屏蔽器数据

  let ipCloaks = {};

  try {
    // 发送请求：根据 id 获取问卷数据
    data = await (0,_services_question__WEBPACK_IMPORTED_MODULE_5__/* .getQuestionById */ .xL)(id);
    const {
      fe_id
    } = data.data;

    if (fe_id) {
      // 获取画页的 lines 数据
      const lines = await (0,_services_question__WEBPACK_IMPORTED_MODULE_5__/* .getLineByDomainName */ .kt)(fe_id);
      const {
        data
      } = lines; // 筛选上线的链接

      if (data.lines) {
        checkeLines = data.lines.lineMessage.filter(line => {
          return line.status === 1;
        });
      }

      if (data.lines.ipCloak) {
        ipCloaks = data.lines.ipCloak;
      }
    }
  } catch (error) {
    console.error("获取数据失败", error);
    data = {
      code: 1,
      msg: "数据获取失败"
    };
  }

  return {
    props: {
      data,
      checkeLines,
      ipCloaks
    }
  };
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8678:
/***/ ((module) => {

// Exports
module.exports = {
	"list": "QuestionCheckbox_list__0oC9J",
	"vertivalItem": "QuestionCheckbox_vertivalItem__H0ckZ",
	"horizontalItem": "QuestionCheckbox_horizontalItem__TxZp0"
};


/***/ }),

/***/ 5544:
/***/ ((module) => {

// Exports
module.exports = {
	"componentWrapper": "Question_componentWrapper__HXB2w",
	"submitBtnContainer": "Question_submitBtnContainer__5hALV"
};


/***/ }),

/***/ 2327:
/***/ (() => {



/***/ }),

/***/ 7066:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5998:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/avatar");

/***/ }),

/***/ 3800:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/button");

/***/ }),

/***/ 2616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 3754:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/flex");

/***/ }),

/***/ 8070:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/image");

/***/ }),

/***/ 675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4779:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/list");

/***/ }),

/***/ 1030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 7374:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/space");

/***/ }),

/***/ 261:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/spin");

/***/ }),

/***/ 8168:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/typography");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 2065:
/***/ ((module) => {

"use strict";
module.exports = import("plyr-react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [480], () => (__webpack_exec__(9523)));
module.exports = __webpack_exports__;

})();