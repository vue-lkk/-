"use strict";
(() => {
var exports = {};
exports.id = 239;
exports.ids = [239];
exports.modules = {

/***/ 8761:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2024);
/* harmony import */ var antd_lib_switch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_switch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7050);
/* harmony import */ var antd_lib_row__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_row__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8518);
/* harmony import */ var antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_col__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2317);
/* harmony import */ var antd_lib_card__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_card__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd_lib_tag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1886);
/* harmony import */ var antd_lib_tag__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tag__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6190);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(antd_lib_form__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3526);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(antd_lib_select__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_line__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(226);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_line__WEBPACK_IMPORTED_MODULE_12__]);
_services_line__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


















const {
  Option
} = (antd_lib_select__WEBPACK_IMPORTED_MODULE_11___default());
function Home(props) {
  const {
    data
  } = props.dataLines;
  const {
    0: templates,
    1: setTemplates
  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)([...data, {
    _id: "custom",
    userName: "",
    nation: "自定义"
  }]);
  const {
    0: isModalOpen,
    1: setIsModalOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false); // 编辑项

  const {
    0: changeLine,
    1: setChangeLine
  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)({}); // 操作类型

  const {
    0: type,
    1: setType
  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)("");

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  }; // 批量添加链接


  const add = async item => {
    setType("add");
    showModal();
    setChangeLine(item);
    console.log("@@@", item); // const data = await addByNation()
  }; // 批量删除链接


  const del = async item => {
    setType("del");
    showModal();
    setChangeLine(item);
    console.log("@@@", item);
  }; // 新建后台


  const create = async item => {
    setType("create");
    showModal();
    setChangeLine(item);
    console.log("@@@", item);
  }; // form
  // Form.Item 可以通过 dependencies 属性，设置关联字段。
  // 当关联字段的值发生变化时，会触发校验与更新。


  const [form] = antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().useForm();

  const users = ["周鹏鹏", "黄水海", "赖春霖", "彭宏", "邓春禹", "郑武康", "周前", "尹英奇", "张康建", "陈炫威", "钟贞兴", "方泽彬", "张天功", "曾强发", "林力梵", "韦恒平", "秦发龙"];
  const {
    0: custom,
    1: setCustom
  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);

  const changeInput = checked => {
    setCustom(checked);
    console.log(checked);
  };

  const [messageApi, contextHolder] = antd_lib_message__WEBPACK_IMPORTED_MODULE_9___default().useMessage(); // 关键！


  const onFinish = async values => {
    try {
      // 批量添加
      if (type === "add") {
        // 根据换行符分割字符串
        const lineArr = values.lineArr?.toString()?.split("\n");
        values.lineArr = lineArr;
        const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_12__/* .addByNation */ .rg)(values);
        messageApi.open({
          type: "success",
          content: "批量添加成功"
        });
      } // 批量删除


      if (type === "del") {
        // 以 ',' 分割数据
        const lineNameArr = values.lineNameArr?.toString()?.split(",");
        values.lineNameArr = lineNameArr;
        const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_12__/* .deleteByNation */ .Ir)(values);
        messageApi.open({
          type: "success",
          content: "批量删除成功"
        });
      } // 新建后台


      if (type === "create") {
        // 处理为字符串
        values.username = values.username?.toString(); // 安全访问

        const {
          nation,
          username,
          domainname
        } = values;
        const data = {
          nation,
          userName: username,
          domainName: domainname
        };
        console.log("1213", data);
        const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_12__/* .createByNation */ .p$)(data);
        console.log(res);

        if (res.code === 202) {
          messageApi.open({
            type: "warning",
            content: res.message
          });
        }

        if (res.code === 201) {
          messageApi.open({
            type: "success",
            content: res.message
          });
        }
      }
    } catch (error) {
      messageApi.open({
        type: "error",
        content: type === "add" ? "批量添加失败，请重试" : "批量删除失败，请重试"
      });
    } finally {
      handleCancel();
    }
  };

  const onFinishFailed = errorInfo => {
    console.log("Failed:", errorInfo);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("div", {
    style: {
      margin: "50px"
    },
    children: [contextHolder, " ", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("div", {
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx("h1", {
        style: {
          marginBottom: "30px"
        },
        children: "\u540E\u53F0\u6A21\u677F"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_row__WEBPACK_IMPORTED_MODULE_4___default()), {
        gutter: [60, 60],
        children: templates && templates.map(item => {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_col__WEBPACK_IMPORTED_MODULE_5___default()), {
            span: 8,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_card__WEBPACK_IMPORTED_MODULE_6___default()), {
              actions: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8___default()), {
                placement: "top",
                title: "\u6279\u91CF\u6DFB\u52A0\u94FE\u63A5",
                color: "blue",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.PlusCircleOutlined, {
                  onClick: () => add(item)
                }, "add")
              }, 1), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8___default()), {
                placement: "top",
                title: "\u6279\u91CF\u5220\u9664\u94FE\u63A5",
                color: "red",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.DeleteOutlined, {
                  onClick: () => del(item)
                }, "del")
              }, 2), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_8___default()), {
                placement: "top",
                title: "\u65B0\u5EFA\u540E\u53F0",
                color: "green",
                children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(_ant_design_icons__WEBPACK_IMPORTED_MODULE_14__.DiffOutlined, {
                  onClick: () => create(item)
                }, "create")
              }, 3)],
              style: {
                minWidth: 300,
                background: "rgb(236 236 236)"
              },
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_card__WEBPACK_IMPORTED_MODULE_6___default().Meta), {
                title: item.nation,
                description: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("p", {
                    children: ["\u6A21\u677F\u57DF\u540D\uFF1A", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_tag__WEBPACK_IMPORTED_MODULE_7___default()), {
                      children: item.domainName
                    })]
                  })
                })
              })
            }, item._id)
          }, item._id);
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_0___default()), {
        title: changeLine.nation,
        open: isModalOpen,
        onOk: handleOk,
        onCancel: handleCancel,
        width: "40%",
        footer: false,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default()), {
          // 当lineName变化时重新创建Form
          name: "basic",
          wrapperCol: {
            span: 16
          },
          style: {
            maxWidth: 600
          },
          initialValues: changeLine,
          onFinish: onFinish,
          onFinishFailed: onFinishFailed,
          autoComplete: "off",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
            label: "\u5E7F\u544A\u7C7B\u578B",
            name: "nation",
            rules: [{
              required: true,
              message: "请输入广告类型:日本-减肥"
            }],
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
              disabled: changeLine._id === "custom" ? false : true
            })
          }), type === "add" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
            label: "\u6279\u91CF\u6DFB\u52A0",
            name: "lineArr",
            rules: [{
              required: true,
              message: "请输入添加的链接"
            }],
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default().TextArea), {
              placeholder: `示例：'链接,备注,号名'
http://pf.kakao.com/_DCxfCn/chat,飞跃,@123
http://pf.kakao.com/_DCxfCn/chat11,312,@167
`,
              autoSize: {
                minRows: 8,
                maxRows: 100
              }
            })
          }), type === "del" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
            label: "\u6279\u91CF\u5220\u9664",
            name: "lineNameArr",
            rules: [{
              required: true,
              message: "请输入删除的号"
            }],
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default().TextArea), {
              placeholder: `示例：@123, @334`,
              autoSize: {
                minRows: 8,
                maxRows: 100
              }
            })
          }), type === "create" && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsxs)("div", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
              label: null,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_switch__WEBPACK_IMPORTED_MODULE_2___default()), {
                checkedChildren: "\u5F00\u542F\u81EA\u5B9A\u4E49",
                unCheckedChildren: "\u5173\u95ED\u81EA\u5B9A\u4E49",
                onChange: changeInput
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
              label: "\u7528\u6237\u540D",
              name: "username",
              rules: [{
                required: true,
                message: "请输入用户名"
              }],
              children: custom ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
                placeholder: "\u8BF7\u9009\u62E9\u7528\u6237\u540D"
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_select__WEBPACK_IMPORTED_MODULE_11___default()), {
                mode: "multiple",
                placeholder: "\u8BF7\u9009\u62E9\u7528\u6237\u540D",
                children: users.map((user, index) => {
                  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx(Option, {
                    value: user,
                    children: user
                  }, index);
                })
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
              label: "\u57DF \u540D",
              name: "domainname",
              rules: [{
                required: true,
                message: "请输入域名"
              }],
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {})
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_10___default().Item), {
            label: null,
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_15__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_1___default()), {
              type: "primary",
              htmlType: "submit",
              children: "\u786E\u5B9A"
            })
          })]
        }, changeLine._id || form || type)
      })]
    })]
  });
} // 请求
// eslint-disable-next-line @typescript-eslint/no-explicit-any

async function getServerSideProps(context) {
  // const { id = "" } = context.params;
  // console.log("@@@", id);
  // 存储返回的后台数据
  let dataLines = null;

  try {
    // 发送请求：根据 id 获取问卷数据
    const res = await (0,_services_line__WEBPACK_IMPORTED_MODULE_12__/* .getQuestionByuserName */ .t$)("lkk");
    dataLines = res;
    console.log(res);
  } catch (error) {
    console.error("获取数据失败", error);
    dataLines = {
      code: 1,
      msg: "数据获取失败"
    };
  }

  return {
    props: {
      dataLines
    }
  };
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 3800:
/***/ ((module) => {

module.exports = require("antd/lib/button");

/***/ }),

/***/ 2317:
/***/ ((module) => {

module.exports = require("antd/lib/card");

/***/ }),

/***/ 8518:
/***/ ((module) => {

module.exports = require("antd/lib/col");

/***/ }),

/***/ 6190:
/***/ ((module) => {

module.exports = require("antd/lib/form");

/***/ }),

/***/ 675:
/***/ ((module) => {

module.exports = require("antd/lib/input");

/***/ }),

/***/ 7369:
/***/ ((module) => {

module.exports = require("antd/lib/message");

/***/ }),

/***/ 6418:
/***/ ((module) => {

module.exports = require("antd/lib/modal");

/***/ }),

/***/ 7050:
/***/ ((module) => {

module.exports = require("antd/lib/row");

/***/ }),

/***/ 3526:
/***/ ((module) => {

module.exports = require("antd/lib/select");

/***/ }),

/***/ 2024:
/***/ ((module) => {

module.exports = require("antd/lib/switch");

/***/ }),

/***/ 1886:
/***/ ((module) => {

module.exports = require("antd/lib/tag");

/***/ }),

/***/ 9348:
/***/ ((module) => {

module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [226], () => (__webpack_exec__(8761)));
module.exports = __webpack_exports__;

})();