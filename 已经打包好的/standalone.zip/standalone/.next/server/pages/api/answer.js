"use strict";
(() => {
var exports = {};
exports.id = 821;
exports.ids = [821];
exports.modules = {

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 201:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _services_answer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7440);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_answer__WEBPACK_IMPORTED_MODULE_0__]);
_services_answer__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// 用户提交数据
function genAnswerInfo(reqBody) {
  const answerList = [];
  Object.keys(reqBody).forEach(key => {
    if (key === "questionId") return;
    answerList.push({
      componentId: key,
      value: reqBody[key]
    });
  });
  return {
    // 问卷id
    questionId: reqBody.questionId || "",
    // 答卷数据
    answerList
  };
}

async function handler(req, res) {
  if (req.method !== "POST") {
    // 不是 post请求 则返回错误
    res.status(200).json({
      error: -1,
      msg: "Method 错误"
    });
  } // 获取到表单提交过来的数据


  console.log("表单数据", req.body); // 获取并格式化表单数据

  const answerInfo = genAnswerInfo(req.body);
  console.log("收集好的提交数据：", answerInfo); // 此时，将数据提交到服务器端

  try {
    // TODO 提交到服务器
    const result = await (0,_services_answer__WEBPACK_IMPORTED_MODULE_0__/* .postAnswer */ .g)(answerInfo);
    console.log("提交成功返回的数据", result); // 如果提交成功了
    // return res.redirect("/success");

    if (result && req.method === "POST") {
      // 处理 POST 请求逻辑
      return res.redirect(302, "/success");
    } else {
      res.status(405).json({
        message: "Method Not Allowed"
      });
    } // 如果提交失败了


    res.redirect("/fail");
  } catch (error) {
    // 如果提交失败了
    console.log(error);
    res.redirect("/fail");
  }

  res.status(200).json({
    code: 0
  });
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7440:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ postAnswer)
/* harmony export */ });
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4995);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_request__WEBPACK_IMPORTED_MODULE_0__]);
_request__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
 // 提交答卷
// eslint-disable-next-line @typescript-eslint/no-explicit-any
// export async function postAnswer(answerInfo:any) {
//   const url = '/api/answer'
//   const data = await post(url,answerInfo)
//   return data
// }

async function postAnswer(answerInfo) {
  return _request__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/api/answer`, answerInfo);
}
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const API_URL = "https://000america.shop:3000"; // 创建 axios 实例

const request = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
  // baseURL: "http://lkkhyy_s.lkkxwj.shop:5502",
  baseURL: API_URL,
  timeout: 5000 // 请求超时时间

}); // 请求拦截器

request.interceptors.request.use(config => {
  // 在这里可以添加全局请求头或 Token
  config.headers["Content-Type"] = "application/json";
  return config;
}, error => {
  return Promise.reject(error);
}); // 响应拦截器

request.interceptors.response.use(response => {
  return response.data; // 只返回数据部分
}, error => {
  console.error("Request error:", error);
  return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (request);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(201));
module.exports = __webpack_exports__;

})();