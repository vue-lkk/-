"use strict";
(() => {
var exports = {};
exports.id = 5;
exports.ids = [5];
exports.modules = {

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 8253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);

const uri = process.env.MONGODB_URI; // const uri = "mongodb://127.0.0.1:27017/mydb";

const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  maxPoolSize: 10,
  // 连接池大小
  serverSelectionTimeoutMS: 5000
};
let client;
let clientPromise;
if (!uri) throw new Error("缺少 MONGODB_URI 环境变量"); // 开发环境使用全局缓存

if (false) {} else {
  client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri, options);
  clientPromise = client.connect();
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clientPromise);

/***/ }),

/***/ 472:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8253);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


async function handler(req, res) {
  // 处理 CORS 预检请求
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    return res.status(200).end();
  } // 设置 CORS 头


  res.setHeader("Access-Control-Allow-Origin", "*");

  if (req.method !== "POST") {
    return res.status(405).json({
      message: "Method not allowed"
    });
  }

  try {
    const {
      userName,
      domainName,
      nation
    } = req.body;
    console.log(userName, domainName, nation); // 验证必要字段

    if (!userName || !domainName || !nation) {
      return res.status(400).json({
        message: "用户名称、域名、国家为必填项"
      });
    } // 连接数据库


    const client = await _lib_mongodb__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z;
    const db = client.db("line"); // 替换为你的数据库名
    // 构建数据格式

    async function createlineList() {
      let templateLines = [];

      switch (nation) {
        case "日本-减肥":
          // 查询数据库
          templateLines = await db.collection("dataEntries").findOne({
            userName: "lkk",
            domainName: "jpjf.com",
            nation
          });
          break;

        case "韩国-减肥":
          // 查询数据库
          templateLines = await db.collection("dataEntries").findOne({
            userName: "lkk",
            domainName: "krjf.com",
            nation
          });
          break;

        case "日本-男科":
          // 查询数据库
          templateLines = await db.collection("dataEntries").findOne({
            userName: "lkk",
            domainName: "jpnk.com",
            nation
          });
          break;

        case "韩国-男科":
          templateLines = [];
          break;

        case "日本-丰胸":
          // 查询数据库
          templateLines = await db.collection("dataEntries").findOne({
            userName: "lkk",
            domainName: "jpfx.com",
            nation
          });
          break;

        default:
          // 自定义
          templateLines = [];
          break;
      }

      return templateLines;
    }

    const lineList = await createlineList();
    console.log("@@@", lineList); // 构建数据对象

    const dataEntry = {
      userName,
      // 用户名称
      domainName,
      // 域名名称
      nation,
      // 国家
      lines: lineList.lines || [],
      // line所有相关信息
      banned: false,
      createdAt: new Date()
    }; // 是否已经创建过后台

    const validDomainName = await db.collection("dataEntries").findOne({
      domainName
    });

    if (validDomainName) {
      res.status(201).json({
        code: 202,
        message: "后台已存在，无需再创建"
      });
    } else {
      // 插入数据库
      const result = await db.collection("dataEntries").insertOne(dataEntry);
      res.status(201).json({
        code: 201,
        message: "后台创建成功",
        data: _objectSpread(_objectSpread({}, dataEntry), {}, {
          _id: result.insertedId
        })
      });
    }
  } catch (error) {
    console.error("Database error:", error);
    res.status(500).json({
      message: "服务器内部错误"
    });
  }
}

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(472));
module.exports = __webpack_exports__;

})();